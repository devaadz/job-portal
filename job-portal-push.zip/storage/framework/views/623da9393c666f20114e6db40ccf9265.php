

<?php $__env->startSection('title', 'Lowongan Pekerjaan - Career Portal'); ?>

<?php $__env->startSection('content'); ?>
<div class="row mb-4">
    <div class="col-md-8">
        <h1>Lowongan Pekerjaan</h1>
    </div>
    <?php if(auth()->guard()->check()): ?>
        <?php if(auth()->user()->isAdmin()): ?>
            <div class="col-md-4 text-end">
                <a href="<?php echo e(route('admin.jobs.create')); ?>" class="btn btn-primary">+ Tambah Lowongan</a>
            </div>
        <?php endif; ?>
    <?php endif; ?>
</div>

<div class="row">
    <?php $__empty_1 = true; $__currentLoopData = $jobs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $job): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <div class="col-md-6 mb-4">
            <div class="card h-100">
                <div class="card-body">
                    <h5 class="card-title"><?php echo e($job->title); ?></h5>
                    <p class="card-text text-muted"><?php echo e(Str::limit($job->description, 100)); ?></p>
                    
                    <?php if($job->skills->count() > 0): ?>
                        <div class="mb-3">
                            <strong>Skill yang dibutuhkan:</strong>
                            <div class="mt-2">
                                <?php $__currentLoopData = $job->skills; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $skill): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <span class="badge bg-light text-dark"><?php echo e($skill->name); ?></span>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                    <?php endif; ?>

                    <div class="d-flex justify-content-between align-items-center">
                        <span class="badge <?php echo e($job->is_active ? 'bg-success' : 'bg-secondary'); ?>">
                            <?php echo e($job->is_active ? 'Aktif' : 'Nonaktif'); ?>

                        </span>
                        <a href="<?php echo e(route('jobs.show', $job)); ?>" class="btn btn-sm btn-primary">Lihat Detail</a>
                    </div>
                </div>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <div class="col-12">
            <div class="alert alert-info">
                Tidak ada lowongan pekerjaan yang tersedia saat ini.
            </div>
        </div>
    <?php endif; ?>
</div>

<!-- Pagination -->
<div class="row mt-4">
    <div class="col-12">
        <?php echo e($jobs->links('pagination::bootstrap-5')); ?>

    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\test-job-portal\job-portal-push\resources\views\jobs\index.blade.php ENDPATH**/ ?>