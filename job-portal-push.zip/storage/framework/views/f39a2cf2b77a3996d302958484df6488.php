

<?php $__env->startSection('title', 'Detail Lamaran - Career Portal'); ?>

<?php $__env->startSection('content'); ?>
<div class="row mb-4">
    <div class="col-12">
        <a href="<?php echo e(route('admin.applications.index')); ?>" class="btn btn-outline-secondary mb-3">← Kembali</a>
        <h1>Detail Lamaran</h1>
    </div>
</div>

<div class="row">
    <div class="col-lg-8">
        <!-- Applicant Profile -->
        <div class="card mb-4">
            <div class="card-header bg-light">
                <h5 class="mb-0">Profil Pelamar</h5>
            </div>
            <div class="card-body">
                <h5><?php echo e($application->applicant->full_name); ?></h5>
                <p>
                    <strong>Email:</strong> <?php echo e($application->applicant->user->email); ?><br>
                    <strong>Phone:</strong> <?php echo e($application->applicant->phone); ?><br>
                    <strong>Deskripsi:</strong> <?php echo e($application->applicant->short_description ?: '-'); ?>

                </p>
                <?php if($application->applicant->cv_file): ?>
                    <div class="mt-3">
                        <p class="mb-2">
                            <strong>CV:</strong> 
                            <small class="text-muted"><?php echo e(basename($application->applicant->cv_original)); ?></small>
                        </p>
                        <a href="<?php echo e(route('admin.applications.download-cv', $application)); ?>" class="btn btn-sm btn-success" download>
                            <i class="bi bi-download"></i> Download CV
                        </a>
                    </div>
                <?php else: ?>
                    <div class="mt-3">
                        <p class="text-muted"><em>CV belum di-upload</em></p>
                    </div>
                <?php endif; ?>
            </div>
        </div>

        <!-- Skills -->
        <div class="card mb-4">
            <div class="card-header bg-light">
                <h5 class="mb-0">Skill Pelamar</h5>
            </div>
            <div class="card-body">
                <?php if($application->applicant->skills->count() > 0): ?>
                    <?php $__currentLoopData = $application->applicant->skills; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $skill): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <span class="badge bg-primary me-2 mb-2"><?php echo e($skill->name); ?></span>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php else: ?>
                    <p class="text-muted mb-0">Belum menambahkan skill</p>
                <?php endif; ?>
            </div>
        </div>

        <!-- Work Experience -->
        <?php if($application->applicant->workExperiences->count() > 0): ?>
            <div class="card mb-4">
                <div class="card-header bg-light">
                    <h5 class="mb-0">Pengalaman Kerja</h5>
                </div>
                <div class="card-body">
                    <?php $__currentLoopData = $application->applicant->workExperiences; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $experience): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="mb-3 pb-3 border-bottom">
                            <h6 class="mb-1"><?php echo e($experience->company_name); ?></h6>
                            <p class="text-muted small mb-2">
                                <?php echo e($experience->start_month); ?>/<?php echo e($experience->start_year); ?> - 
                                <?php echo e($experience->end_month); ?>/<?php echo e($experience->end_year); ?>

                            </p>
                            <p class="mb-0"><?php echo e($experience->description); ?></p>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        <?php endif; ?>

        <!-- Education -->
        <?php if($application->applicant->education): ?>
            <div class="card mb-4">
                <div class="card-header bg-light">
                    <h5 class="mb-0">Pendidikan</h5>
                </div>
                <div class="card-body">
                    <p>
                        <strong>Universitas:</strong> <?php echo e($application->applicant->education->university); ?><br>
                        <strong>Jurusan:</strong> <?php echo e($application->applicant->education->major); ?><br>
                        <strong>Lama Studi:</strong> <?php echo e($application->applicant->education->study_duration_year); ?> tahun<br>
                        <strong>IPK:</strong> <?php echo e($application->applicant->education->gpa ?? '-'); ?>

                    </p>
                </div>
            </div>
        <?php endif; ?>

        <!-- Job Details -->
        <div class="card mb-4">
            <div class="card-header bg-light">
                <h5 class="mb-0">Detail Posisi</h5>
            </div>
            <div class="card-body">
                <h5><?php echo e($application->job->title); ?></h5>
                <p><?php echo e($application->job->description); ?></p>
                
                <div class="mt-3">
                    <strong>Skill yang Dibutuhkan:</strong>
                    <div class="mt-2">
                        <?php $__currentLoopData = $application->job->skills; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $skill): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <span class="badge bg-warning text-dark me-2"><?php echo e($skill->name); ?></span>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
        </div>

        <!-- Application Logs -->
        <div class="card">
            <div class="card-header bg-light">
                <h5 class="mb-0">Riwayat Perubahan Status</h5>
            </div>
            <div class="card-body">
                <?php if($application->logs->count() > 0): ?>
                    <div class="timeline">
                        <?php $__currentLoopData = $application->logs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $log): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="timeline-item mb-3">
                                <p class="text-muted small mb-1"><?php echo e($log->created_at->format('d M Y H:i')); ?></p>
                                <p class="mb-1">
                                    <strong><?php echo e($log->changedByUser->name); ?></strong> 
                                    mengubah status dari <span class="badge bg-secondary"><?php echo e($log->old_status); ?></span> 
                                    ke <span class="badge bg-success"><?php echo e($log->new_status); ?></span>
                                </p>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                <?php else: ?>
                    <p class="text-muted mb-0">Belum ada riwayat perubahan</p>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <!-- Sidebar -->
    <div class="col-lg-4">
        <!-- Screening Result -->
        <div class="card mb-4">
            <div class="card-header bg-light">
                <h5 class="mb-0">Hasil Screening</h5>
            </div>
            <div class="card-body">
                <?php if($application->screening_result): ?>
                    <p>
                        <strong>Status:</strong> 
                        <span class="badge bg-info"><?php echo e($application->screeningResultLabelAttribute); ?></span>
                    </p>
                <?php else: ?>
                    <p class="text-muted">Belum di-screening</p>
                <?php endif; ?>
            </div>
        </div>

        <!-- Application Status -->
        <div class="card mb-4">
            <div class="card-header bg-light">
                <h5 class="mb-0">Status Lamaran</h5>
            </div>
            <div class="card-body">
                <form method="POST" action="<?php echo e(route('admin.applications.update-status', $application)); ?>">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PATCH'); ?>

                    <div class="mb-3">
                        <label for="status" class="form-label">Status</label>
                        <select class="form-select <?php $__errorArgs = ['status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="status" name="status" required>
                            <option value="applied" <?php echo e($application->status === 'applied' ? 'selected' : ''); ?>>Melamar</option>
                            <option value="screening" <?php echo e($application->status === 'screening' ? 'selected' : ''); ?>>Screening</option>
                            <option value="interview" <?php echo e($application->status === 'interview' ? 'selected' : ''); ?>>Interview</option>
                            <option value="accepted" <?php echo e($application->status === 'accepted' ? 'selected' : ''); ?>>Diterima</option>
                            <option value="rejected" <?php echo e($application->status === 'rejected' ? 'selected' : ''); ?>>Ditolak</option>
                        </select>
                        <?php $__errorArgs = ['status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="mb-3">
                        <label for="current_step" class="form-label">Tahap Saat Ini</label>
                        <select class="form-select <?php $__errorArgs = ['current_step'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="current_step" name="current_step" required>
                            <option value="screening" <?php echo e($application->current_step === 'screening' ? 'selected' : ''); ?>>Screening</option>
                            <option value="interview" <?php echo e($application->current_step === 'interview' ? 'selected' : ''); ?>>Interview</option>
                            <option value="final" <?php echo e($application->current_step === 'final' ? 'selected' : ''); ?>>Final</option>
                        </select>
                        <?php $__errorArgs = ['current_step'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <button type="submit" class="btn btn-primary w-100">Update Status</button>
                </form>
            </div>
        </div>

        <!-- Application Info -->
        <div class="card">
            <div class="card-header bg-light">
                <h5 class="mb-0">Informasi Lamaran</h5>
            </div>
            <div class="card-body">
                <p class="mb-2">
                    <strong>Tanggal Melamar:</strong><br>
                    <?php echo e($application->created_at->format('d M Y H:i')); ?>

                </p>
                <p class="mb-0">
                    <strong>Terakhir Update:</strong><br>
                    <?php echo e($application->updated_at->format('d M Y H:i')); ?>

                </p>
            </div>
        </div>
    </div>
</div>

<style>
    .timeline {
        position: relative;
        padding-left: 0;
    }

    .timeline-item {
        padding-left: 20px;
        position: relative;
    }

    .timeline-item::before {
        content: '';
        position: absolute;
        left: 0;
        top: 5px;
        width: 10px;
        height: 10px;
        background-color: #2563eb;
        border-radius: 50%;
    }

    .timeline-item::after {
        content: '';
        position: absolute;
        left: 4px;
        top: 15px;
        width: 2px;
        height: 30px;
        background-color: #e2e8f0;
    }

    .timeline-item:last-child::after {
        display: none;
    }
</style>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\test-job-portal\job-portal-push\resources\views\admin\applications\show.blade.php ENDPATH**/ ?>