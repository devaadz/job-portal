

<?php $__env->startSection('title', 'Kelola Skill - Career Portal'); ?>
 
<?php $__env->startSection('content'); ?>
<div class="row mb-4">
    <div class="col-md-8">
        <h1>Kelola Skill</h1>
    </div>
    <div class="col-md-4 text-end">
        <a href="<?php echo e(route('admin.skills.create')); ?>" class="btn btn-primary">+ Tambah Skill</a>
    </div>
</div>

<div class="card">
    <div class="row mb-3 align-items-center">
        <div class="col-md-4">
            <form method="GET" action="<?php echo e(route('admin.skills.index')); ?>">
                <div class="input-group">
                    <input 
                        type="text" 
                        name="search" 
                        class="form-control"
                        placeholder="Cari skill..."
                        value="<?php echo e(request('search')); ?>"
                    >
                    <button class="btn btn-outline-secondary" type="submit">Cari</button>
                </div>
            </form>
        </div>

        <div class="col-md-4">
            <form method="GET" action="<?php echo e(route('admin.skills.index')); ?>">
                <div class="input-group">
                    <label class="input-group-text">Tampilkan</label>
                    <select name="perPage" class="form-select" onchange="this.form.submit()">
                        <?php $__currentLoopData = [10,20,50,100]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $size): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($size); ?>" <?php echo e($perPage == $size ? 'selected' : ''); ?>>
                                <?php echo e($size); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <!-- Keep search query if exists -->
                <input type="hidden" name="search" value="<?php echo e(request('search')); ?>">
            </form>
        </div>

        <div class="col-md-4 text-end">
            <span class="text-muted">
                Menampilkan <?php echo e($skills->count()); ?> dari <?php echo e($totalSkills); ?> skill
            </span>
        </div>
    </div>


    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-hover mb-0">
                <thead class="table-light">
                    <tr>
                        <th>Nama Skill</th>
                        <th>Digunakan dalam Lowongan</th>
                        <th>Dimiliki Pelamar</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $skills; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $skill): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td>
                                <strong><?php echo e($skill->name); ?></strong>
                            </td>
                            <td><?php echo e($skill->jobs->count()); ?> lowongan</td>
                            <td><?php echo e($skill->applicants->count()); ?> pelamar</td>
                            <td>
                                <div class="btn-group" role="group">
                                    <a href="<?php echo e(route('admin.skills.edit', $skill)); ?>" class="btn btn-sm btn-warning">Edit</a>
                                    <form method="POST" action="<?php echo e(route('admin.skills.delete', $skill)); ?>" 
                                          style="display: inline;" onsubmit="return confirm('Hapus skill ini?');">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="submit" class="btn btn-sm btn-danger">Hapus</button>
                                    </form>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="4" class="text-center text-muted py-4">
                                Tidak ada skill. <a href="<?php echo e(route('admin.skills.create')); ?>">Tambah sekarang</a>
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<div class="row mt-4 align-items-center">
    <div class="col-md-6 text-muted">
        Menampilkan <?php echo e($skills->firstItem()); ?> – <?php echo e($skills->lastItem()); ?> dari <?php echo e($skills->total()); ?> data
    </div>
    <div class="col-md-6 text-end">
        <?php echo e($skills->links('pagination::bootstrap-5')); ?>

    </div>
</div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\test-job-portal\job-portal-push\resources\views\admin\skills\index.blade.php ENDPATH**/ ?>