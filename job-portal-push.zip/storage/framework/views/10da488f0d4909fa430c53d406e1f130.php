

<?php $__env->startSection('title', $job->title . ' - Career Portal'); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-lg-8">
        <div class="card mb-4">
            <div class="card-body">
                <h1 class="card-title mb-3"><?php echo e($job->title); ?></h1>
                
                <div class="mb-4">
                    <span class="badge <?php echo e($job->is_active ? 'bg-success' : 'bg-danger'); ?>">
                        <?php echo e($job->is_active ? 'Lowongan Aktif' : 'Lowongan Ditutup'); ?>

                    </span>
                </div>

                <div class="mb-4">
                    <h5>Deskripsi Pekerjaan</h5>
                    <p><?php echo e(nl2br($job->description)); ?></p>
                </div>

                <?php if($job->skills->count() > 0): ?>
                    <div class="mb-4">
                        <h5>Skill yang Dibutuhkan</h5>
                        <div>
                            <?php $__currentLoopData = $job->skills; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $skill): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <span class="badge bg-primary me-2 mb-2"><?php echo e($skill->name); ?></span>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                <?php endif; ?>

                <div class="d-flex gap-2">
                    <?php if(auth()->guard()->check()): ?>
                        <?php if(auth()->user()->isApplicant()): ?>
                            <?php if($userApplication): ?>
                                <span class="badge bg-success py-2">Sudah melamar</span>
                                <form method="POST" action="<?php echo e(route('applicant.withdraw', $userApplication)); ?>" 
                                      onsubmit="return confirm('Yakin ingin menarik lamaran?');">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="btn btn-danger">Tarik Lamaran</button>
                                </form>
                            <?php else: ?>
                                <form method="POST" action="<?php echo e(route('applicant.apply', $job)); ?>">
                                    <?php echo csrf_field(); ?>
                                    <button type="submit" class="btn btn-primary">Melamar Pekerjaan</button>
                                </form>
                            <?php endif; ?>
                        <?php endif; ?>
                    <?php else: ?>
                        <a href="<?php echo e(route('login')); ?>" class="btn btn-primary">Login untuk Melamar</a>
                    <?php endif; ?>

                    <a href="<?php echo e(route('jobs.index')); ?>" class="btn btn-outline-secondary">Kembali</a>
                </div>
            </div>
        </div>
    </div>

    <div class="col-lg-4">
        <div class="card">
            <div class="card-header bg-light">
                <h5 class="mb-0">Informasi Lowongan</h5>
            </div>
            <div class="card-body">
                <p class="mb-2">
                    <strong>Total Pelamar:</strong> <?php echo e($job->applications->count()); ?>

                </p>
                <p class="mb-2">
                    <strong>Dibuat:</strong> <?php echo e($job->created_at->format('d M Y')); ?>

                </p>
                <p class="mb-0">
                    <strong>Terakhir Update:</strong> <?php echo e($job->updated_at->format('d M Y')); ?>

                </p>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\test-job-portal\job-portal-push\resources\views\jobs\show.blade.php ENDPATH**/ ?>