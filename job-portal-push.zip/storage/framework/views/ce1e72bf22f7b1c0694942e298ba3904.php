<!-- resources/views/admin/applications/index.blade.php -->


<?php $__env->startSection('title', 'Screening Lamaran - Career Portal'); ?>

<?php $__env->startSection('content'); ?>
<div class="row mb-4">
    <div class="col-md-8">
        <h1>Screening Lamaran</h1>
    </div>
</div>


<form id="filter-form" class="row g-3 mb-3">
    <div class="col-md-3">
        <input type="text" name="search" class="form-control" placeholder="Cari pelamar / posisi" value="<?php echo e(request('search')); ?>">
    </div>

    <div class="col-md-2">
        <select name="status" class="form-select">
            <option value="">Semua Status</option>
            <option value="pending" <?php echo e(request('status') == 'pending' ? 'selected' : ''); ?>>Pending</option>
            <option value="accepted" <?php echo e(request('status') == 'accepted' ? 'selected' : ''); ?>>Diterima</option>
            <option value="rejected" <?php echo e(request('status') == 'rejected' ? 'selected' : ''); ?>>Ditolak</option>
        </select>
    </div>

    <div class="col-md-3">
        <select name="job_id" class="form-select">
            <option value="">Semua Posisi</option>
            <?php $__currentLoopData = $jobs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $job): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($job->id); ?>" <?php echo e(request('job_id') == $job->id ? 'selected' : ''); ?>><?php echo e($job->title); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </div>

    <div class="col-md-2">
        <select name="per_page" class="form-select">
            <option value="10" <?php echo e(request('per_page') == 10 ? 'selected' : ''); ?>>10 / halaman</option>
            <option value="25" <?php echo e(request('per_page') == 25 ? 'selected' : ''); ?>>25 / halaman</option>
            <option value="50" <?php echo e(request('per_page') == 50 ? 'selected' : ''); ?>>50 / halaman</option>
            <option value="100" <?php echo e(request('per_page') == 100 ? 'selected' : ''); ?>>100 / halaman</option>
        </select>
    </div>
</form>

<div id="applications-table" class="table-responsive">
    <table class="table table-hover mb-0">
        <thead class="table-light">
            <tr>
                <th>Pelamar</th>
                <th>Posisi</th>
                <th>Status</th>
                <th>Hasil Screening</th>
                <th>Tahap</th>
                <th>Tanggal Melamar</th>
                <th>Aksi</th>
            </tr>
        </thead>
        <tbody></tbody>
    </table>
    <div id="pagination-links" class="mt-3"></div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script>
document.addEventListener('DOMContentLoaded', function() {
    const form = document.getElementById('filter-form');
    const tableDiv = document.getElementById('applications-table');

    // Filter saat change (tidak kirim event ke submitForm)
    form.querySelectorAll('input, select').forEach(el => {
        el.addEventListener('change', () => submitForm());
    });

    // Load pertama kali
    submitForm();

    function submitForm(url = null) {
        const formData = new FormData(form);
        const query = new URLSearchParams(formData).toString();
        const fetchUrl = url ? url : "<?php echo e(route('admin.applications.index')); ?>?" + query;

        fetch(fetchUrl, { headers: { 'X-Requested-With': 'XMLHttpRequest' } })
            .then(res => res.json())
            .then(json => renderTable(json.data, json.pagination))
            .catch(err => console.error(err));
    }

    function renderTable(applications, pagination) {
        if (!applications) return;

        let html = `<table class="table table-hover mb-0">
            <thead class="table-light">
                <tr>
                    <th>Pelamar</th>
                    <th>Posisi</th>
                    <th>Status</th>
                    <th>Hasil Screening</th>
                    <th>Tahap</th>
                    <th>Tanggal Melamar</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>`;

        if (applications.length > 0) {
            applications.forEach(app => {
                html += `<tr>
                    <td>${app.applicant.full_name}</td>
                    <td><a href="/jobs/${app.job.id}" class="text-decoration-none">${app.job.title}</a></td>
                    <td>
                        <span class="badge bg-${app.status === 'accepted' ? 'success' : (app.status === 'rejected' ? 'danger' : 'warning')}">
                            ${app.status_label}
                        </span>
                    </td>
                    <td>${app.screening_result ? `<span class="badge bg-info">${app.screening_result_label}</span>` : '<span class="text-muted">-</span>'}</td>
                    <td>${app.current_step.charAt(0).toUpperCase() + app.current_step.slice(1)}</td>
                    <td>${(new Date(app.created_at)).toLocaleDateString('id-ID', {day:'2-digit', month:'short', year:'numeric'})}</td>
                    <td>
                        <a href="/admin/applications/${app.id}" class="btn btn-sm btn-primary">Lihat Detail</a>
                    </td>
                </tr>`;
            });
        } else {
            html += `<tr>
                <td colspan="7" class="text-center text-muted py-4">Tidak ada lamaran.</td>
            </tr>`;
        }

        html += `</tbody></table>`;

        // Pagination
        if (pagination.last_page > 1) {
            html += `<nav class="mt-3"><ul class="pagination">`;
            for (let i = 1; i <= pagination.last_page; i++) {
                html += `<li class="page-item ${i === pagination.current_page ? 'active' : ''}">
                    <a class="page-link" href="#" data-page="${i}">${i}</a>
                </li>`;
            }
            html += `</ul></nav>`;
        }

        tableDiv.innerHTML = html;

        // Pagination click
        tableDiv.querySelectorAll('.page-link').forEach(link => {
            link.addEventListener('click', function(e) {
                e.preventDefault();
                const page = this.dataset.page;
                const url = "<?php echo e(route('admin.applications.index')); ?>" + "?page=" + page + "&" + new URLSearchParams(new FormData(form)).toString();
                submitForm(url);
            });
        });
    }
});
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\test-job-portal\job-portal-push\resources\views\admin\applications\index.blade.php ENDPATH**/ ?>