

<?php $__env->startSection('title', 'Dashboard Pelamar - Career Portal'); ?>

<?php $__env->startSection('content'); ?>
<div class="row mb-4">
    <div class="col-md-8">
        <h1>Dashboard Pelamar</h1>
    </div>
    <div class="col-md-4 text-end">
        <a href="<?php echo e(route('applicant.edit-profile')); ?>" class="btn btn-primary">Edit Profil</a>
    </div>
</div>

<!-- Profile Summary Card -->
<div class="row mb-4">
    <div class="col-lg-3">
        <div class="card">
            <div class="card-body text-center">
                <h3><?php echo e($applicant->applications->count()); ?></h3>
                <p class="text-muted mb-0">Total Lamaran</p>
            </div>
        </div>
    </div>
    <div class="col-lg-3">
        <div class="card">
            <div class="card-body text-center">
                <h3><?php echo e($applicant->applications->where('status', 'accepted')->count()); ?></h3>
                <p class="text-muted mb-0">Diterima</p>
            </div>
        </div>
    </div>
    <div class="col-lg-3">
        <div class="card">
            <div class="card-body text-center">
                <h3><?php echo e($applicant->applications->where('status', 'screening')->count()); ?></h3>
                <p class="text-muted mb-0">Screening</p>
            </div>
        </div>
    </div>
    <div class="col-lg-3">
        <div class="card">
            <div class="card-body text-center">
                <h3><?php echo e($applicant->skills->count()); ?></h3>
                <p class="text-muted mb-0">Skill</p>
            </div>
        </div>
    </div>
</div>

<!-- Profile Information -->
<div class="row mb-4">
    <div class="col-lg-8">
        <div class="card">
            <div class="card-header bg-light">
                <h5 class="mb-0">Informasi Profil</h5>
            </div>
            <div class="card-body">
                <p><strong>Nama:</strong> <?php echo e($applicant->full_name); ?></p>
                <p><strong>Email:</strong> <?php echo e(auth()->user()->email); ?></p>
                <p><strong>Phone:</strong> <?php echo e($applicant->phone ?: 'Belum diisi'); ?></p>
                <p><strong>Deskripsi:</strong> <?php echo e($applicant->short_description ?: 'Belum diisi'); ?></p>
                <p class="mb-0"><strong>CV:</strong> 
                    <?php if($applicant->cv_file): ?>
                        <br>
                        <small class="text-muted">
                            File: <strong><?php echo e(basename($applicant->cv_original)); ?></strong>
                        </small>
                        <br>
                        <a href="<?php echo e(route('applicant.download-cv')); ?>" class="btn btn-sm btn-success mt-2">
                            <i class="bi bi-download"></i> Download CV
                        </a>
                    <?php else: ?>
                        <span class="text-muted">Belum upload CV</span>
                    <?php endif; ?>
                </p>
            </div>
        </div>
    </div>
    <div class="col-lg-4">
        <div class="card">
            <div class="card-header bg-light">
                <h5 class="mb-0">Skill</h5>
            </div>
            <div class="card-body">
                <?php if($applicant->skills->count() > 0): ?>
                    <?php $__currentLoopData = $applicant->skills; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $skill): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <span class="badge bg-primary me-2 mb-2"><?php echo e($skill->name); ?></span>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php else: ?>
                    <p class="text-muted mb-0">Belum menambahkan skill</p>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<!-- Applications Status -->
<div class="row">
    <div class="col-12">
        <div class="card">
            <div class="card-header bg-light">
                <h5 class="mb-0">Status Lamaran</h5>
            </div>
            <div class="card-body">
                <?php if($applicant->applications->count() > 0): ?>
                    <div class="table-responsive">
                        <table class="table table-hover mb-0">
                            <thead class="table-light">
                                <tr>
                                    <th>Posisi</th>
                                    <th>Status</th>
                                    <th>Tahap</th>
                                    <th>Tanggal Melamar</th>
                                    <th>Aksi</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $applicant->applications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $application): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td>
                                            <a href="<?php echo e(route('jobs.show', $application->job)); ?>">
                                                <?php echo e($application->job->title); ?>

                                            </a>
                                        </td>
                                        <td>
                                            <span class="badge bg-<?php echo e($application->status === 'accepted' ? 'success' : ($application->status === 'rejected' ? 'danger' : 'warning')); ?>">
                                                <?php echo e($application->status); ?>

                                            </span>
                                        </td>       
                                        <td>
                                            <small class="text-muted"><?php echo e(ucfirst($application->current_step)); ?></small>
                                        </td>
                                        <td><?php echo e($application->created_at->format('d M Y')); ?></td>
                                        <td>
                                            <?php if($application->status !== 'rejected' && $application->status !== 'accepted'): ?>
                                                <form method="POST" action="<?php echo e(route('applicant.withdraw', $application)); ?>" 
                                                      style="display: inline;" 
                                                      onsubmit="return confirm('Yakin ingin menarik lamaran?');">
                                                    <?php echo csrf_field(); ?>
                                                    <?php echo method_field('DELETE'); ?>
                                                    <button type="submit" class="btn btn-sm btn-danger">Tarik</button>
                                                </form>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                <?php else: ?>
                    <div class="alert alert-info mb-0">
                        Anda belum melamar ke posisi manapun. <a href="<?php echo e(route('jobs.index')); ?>">Lihat lowongan pekerjaan</a>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\test-job-portal\job-portal-push\resources\views\applicant\dashboard.blade.php ENDPATH**/ ?>