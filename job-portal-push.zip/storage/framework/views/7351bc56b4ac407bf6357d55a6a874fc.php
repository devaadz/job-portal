

<?php $__env->startSection('title', 'Edit Profil - Career Portal'); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-lg-8 offset-lg-2">
        <h1 class="mb-4">Edit Profil Pelamar</h1>
        <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <ul class="mb-0">
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>

        <ul class="nav nav-tabs mb-4" role="tablist">
            <li class="nav-item">
                <a class="nav-link active" data-bs-toggle="tab" href="#personal">Data Pribadi</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" data-bs-toggle="tab" href="#skills">Skill</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" data-bs-toggle="tab" href="#experience">Pengalaman Kerja</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" data-bs-toggle="tab" href="#education">Pendidikan</a>
            </li>
        </ul>

        <div class="tab-content">
            <!-- Personal Data Tab -->
            <div id="personal" class="tab-pane fade show active">
                <div class="card">
                    <div class="card-body">
                        <form method="POST" action="<?php echo e(route('applicant.update-profile')); ?>" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>

                            <div class="mb-3">
                                <label for="full_name" class="form-label">Nama Lengkap</label>
                                <input type="text" class="form-control <?php $__errorArgs = ['full_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                       id="full_name" name="full_name" value="<?php echo e(old('full_name', $applicant->full_name)); ?>" required>
                                <?php $__errorArgs = ['full_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="mb-3">
                                <label for="phone" class="form-label">No. Telepon</label>
                                <input type="tel" class="form-control <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                       id="phone" name="phone" value="<?php echo e(old('phone', $applicant->phone)); ?>" required>
                                <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="mb-3">
                                <label for="short_description" class="form-label">Deskripsi Singkat</label>
                                <textarea class="form-control <?php $__errorArgs = ['short_description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                          id="short_description" name="short_description" rows="4"><?php echo e(old('short_description', $applicant->short_description)); ?></textarea>
                                <?php $__errorArgs = ['short_description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="mb-3">
                                <label for="cv_file" class="form-label">Upload CV (PDF/DOC/DOCX)</label>
                                <?php if($applicant->cv_file): ?>
                                    <p class="text-muted small">
                                        File saat ini: <a href="<?php echo e(asset('storage/' . $applicant->cv_file)); ?>" target="_blank">Download</a>
                                    </p>
                                <?php endif; ?>
                                <input type="file" class="form-control <?php $__errorArgs = ['cv_file'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                       id="cv_file" name="cv_file" accept=".pdf,.doc,.docx">
                                <?php $__errorArgs = ['cv_file'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <button type="submit" class="btn btn-primary">Simpan Perubahan</button>
                        </form>
                    </div>
                </div>
            </div>

            <!-- Skills Tab -->
            
            <div id="skills" class="tab-pane fade">
                <div class="card">
                    <div class="card-body">
                        <form method="POST" action="<?php echo e(route('applicant.skills.update')); ?>">
                            <?php echo csrf_field(); ?>

                            
                            <div class="mb-3">
                                <label class="form-label">Cari Skill</label>
                                <input type="text" id="skillSearch" class="form-control" placeholder="Ketik nama skill...">
                            </div>

                            
                            <div class="mb-3">
                                <label class="form-label">Tambah Skill Baru</label>
                                <input type="text" id="newSkillInput" class="form-control"
                                    placeholder="Contoh: Laravel, Docker, Figma">
                                <small class="text-muted">Tekan Enter (maks total 15 skill)</small>
                                <div id="newSkillContainer" class="mt-2"></div>
                            </div>

                            
                            <div class="border p-3 rounded" style="max-height:300px; overflow-y:auto;">
                                <?php $__currentLoopData = $allSkills; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $skill): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="form-check skill-item">
                                        <input class="form-check-input skill-checkbox"
                                            type="checkbox"
                                            name="skills[]"
                                            value="<?php echo e($skill->id); ?>"
                                            id="skill_<?php echo e($skill->id); ?>"
                                            <?php echo e($applicant->skills->contains($skill->id) ? 'checked' : ''); ?>>
                                        <label class="form-check-label" for="skill_<?php echo e($skill->id); ?>">
                                            <?php echo e($skill->name); ?>

                                        </label>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>

                            
                            <input type="hidden" name="new_skills" id="newSkillsHidden">

                            <?php $__errorArgs = ['skills'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="text-danger mt-2"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                            <button type="submit" class="btn btn-primary mt-3">
                                Simpan Skill
                            </button>
                        </form>
                    </div>
                </div>
            </div>


            <!-- Work Experience Tab -->
            <div id="experience" class="tab-pane fade">
                <div class="card mb-4">
                    <div class="card-header bg-light">
                        <h5 class="mb-0">Daftar Pengalaman Kerja</h5>
                    </div>
                    <div class="card-body">
                        <?php $__empty_1 = true; $__currentLoopData = $applicant->workExperiences; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $experience): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <div class="card mb-3 border">
                                <div class="card-body">
                                    <h6><?php echo e($experience->company_name); ?></h6>
                                    <p class="text-muted small mb-2">
                                        <?php echo e($experience->start_month); ?>/<?php echo e($experience->start_year); ?> - 
                                        <?php echo e($experience->end_month); ?>/<?php echo e($experience->end_year); ?>

                                        <strong>(<?php echo e($experience->duration); ?>)</strong>
                                    </p>
                                    <p><?php echo e($experience->description); ?></p>
                                    <form method="POST" action="<?php echo e(route('applicant.work-experience.delete', $experience)); ?>" 
                                          style="display: inline;" onsubmit="return confirm('Hapus pengalaman ini?');">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="submit" class="btn btn-sm btn-danger">Hapus</button>
                                    </form>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <p class="text-muted">Belum menambahkan pengalaman kerja</p>
                        <?php endif; ?>
                    </div>
                </div>

                <div class="card">
                    <div class="card-header bg-light">
                        <h5 class="mb-0">Tambah Pengalaman Kerja</h5>
                    </div>
                    <div class="card-body">
                        <form method="POST" action="<?php echo e(route('applicant.work-experience.add')); ?>">
                            <?php echo csrf_field(); ?>

                            <div class="mb-3">
                                <label for="company_name" class="form-label">Nama Perusahaan</label>
                                <input type="text" class="form-control <?php $__errorArgs = ['company_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                       id="company_name" name="company_name" required>
                                <?php $__errorArgs = ['company_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="row">
                                <div class="col-md-6 mb-3">
                                    <label for="start_month" class="form-label">Bulan Mulai</label>
                                    <select class="form-select <?php $__errorArgs = ['start_month'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                            id="start_month" name="start_month" required>
                                        <option value="">Pilih bulan</option>
                                        <?php for($i = 1; $i <= 12; $i++): ?>
                                            <option value="<?php echo e($i); ?>"><?php echo e($i); ?></option>
                                        <?php endfor; ?>
                                    </select>
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label for="start_year" class="form-label">Tahun Mulai</label>
                                    <input type="number" class="form-control <?php $__errorArgs = ['start_year'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                           id="start_year" name="start_year" min="1970" required>
                                </div>
                            </div>

                            <div class="row">
                                <div class="col-md-6 mb-3">
                                    <label for="end_month" class="form-label">Bulan Selesai</label>
                                    <select class="form-select <?php $__errorArgs = ['end_month'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                            id="end_month" name="end_month" required>
                                        <option value="">Pilih bulan</option>
                                        <?php for($i = 1; $i <= 12; $i++): ?>
                                            <option value="<?php echo e($i); ?>"><?php echo e($i); ?></option>
                                        <?php endfor; ?>
                                    </select>
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label for="end_year" class="form-label">Tahun Selesai</label>
                                    <input type="number" class="form-control <?php $__errorArgs = ['end_year'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                           id="end_year" name="end_year" min="1970" required>
                                </div>
                            </div>

                            <div class="mb-3">
                                <label for="description" class="form-label">Deskripsi</label>
                                <textarea class="form-control <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                          id="description" name="description" rows="3" required></textarea>
                                <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <button type="submit" class="btn btn-primary">Tambah Pengalaman</button>
                        </form>
                    </div>
                </div>
            </div>

            <!-- Education Tab -->
            <div id="education" class="tab-pane fade">
                <div class="card">
                    <div class="card-header bg-light">
                        <h5 class="mb-0">Informasi Pendidikan</h5>
                    </div>
                    <div class="card-body">
                        <form method="POST" action="<?php echo e(route('applicant.education.add')); ?>">
                            <?php echo csrf_field(); ?>

                            <div class="mb-3">
                                <label for="university" class="form-label">Universitas</label>
                                <input type="text" class="form-control <?php $__errorArgs = ['university'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                       id="university" name="university" 
                                       value="<?php echo e(old('university', $applicant->education->university ?? '')); ?>">
                                <?php $__errorArgs = ['university'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="mb-3">
                                <label for="major" class="form-label">Jurusan</label>
                                <input type="text" class="form-control <?php $__errorArgs = ['major'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                       id="major" name="major" 
                                       value="<?php echo e(old('major', $applicant->education->major ?? '')); ?>">
                                <?php $__errorArgs = ['major'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="row">
                                <div class="col-md-6 mb-3">
                                    <label for="study_duration_year" class="form-label">Lama Studi (Tahun)</label>
                                    <input type="number" class="form-control <?php $__errorArgs = ['study_duration_year'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                           id="study_duration_year" name="study_duration_year" min="1" 
                                           value="<?php echo e(old('study_duration_year', $applicant->education->study_duration_year ?? '')); ?>">
                                    <?php $__errorArgs = ['study_duration_year'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label for="gpa" class="form-label">IPK</label>
                                    <input type="number" step="0.01" class="form-control <?php $__errorArgs = ['gpa'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                           id="gpa" name="gpa" min="0" max="4" 
                                           value="<?php echo e(old('gpa', $applicant->education->gpa ?? '')); ?>">
                                    <?php $__errorArgs = ['gpa'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>

                            <button type="submit" class="btn btn-primary">Simpan Pendidikan</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script>
const maxSkills = 15;
let newSkills = [];

// search skill
document.getElementById('skillSearch').addEventListener('input', function () {
    const q = this.value.toLowerCase();
    document.querySelectorAll('.skill-item').forEach(item => {
        item.style.display = item.innerText.toLowerCase().includes(q) ? '' : 'none';
    });
});

// hitung total
function totalSelected() {
    return document.querySelectorAll('.skill-checkbox:checked').length + newSkills.length;
}

// add skill baru
document.getElementById('newSkillInput').addEventListener('keypress', function (e) {
    if (e.key !== 'Enter') return;
    e.preventDefault();

    let skill = this.value.trim().toLowerCase();
    if (!skill) return;

    if (totalSelected() >= maxSkills) {
        alert('Maksimal 15 skill');
        return;
    }

    // cek apakah skill sudah ada di checkbox
    const existing = [...document.querySelectorAll('.skill-checkbox')]
        .find(cb => cb.nextElementSibling.innerText.toLowerCase() === skill);

    // kalau sudah ada → auto checklist
    if (existing) {
        existing.checked = true;
        this.value = '';
        return;
    }

    // cek duplikat new skill
    if (newSkills.includes(skill)) {
        this.value = '';
        return;
    }

    newSkills.push(skill);
    updateHidden();

    const badge = document.createElement('span');
    badge.className = 'badge bg-secondary me-2 mb-2';
    badge.dataset.skill = skill;
    badge.innerHTML = `${skill}
        <span style="cursor:pointer" onclick="removeNewSkill(this)"> ×</span>`;

    document.getElementById('newSkillContainer').appendChild(badge);
    this.value = '';
});

// remove new skill
function removeNewSkill(el) {
    const skill = el.parentElement.dataset.skill;
    newSkills = newSkills.filter(s => s !== skill);
    el.parentElement.remove();
    updateHidden();
}

// limit checkbox
document.querySelectorAll('.skill-checkbox').forEach(cb => {
    cb.addEventListener('change', function () {
        if (totalSelected() > maxSkills) {
            alert('Maksimal 15 skill');
            this.checked = false;
        }
    });
});

function updateHidden() {
    document.getElementById('newSkillsHidden').value = JSON.stringify(newSkills);
}
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\test-job-portal\job-portal-push\resources\views\applicant\edit-profile.blade.php ENDPATH**/ ?>